# Description

finishing and modifying maps from other packs that don't have spawns, or no longer function. might even add some new ones.

# Included Maps
disable the originals ingame in MODS > TOGGLE LEVELS > {original mod} to avoid broken mechanics (such as softlocking your game when they load because there are no spawns on the map).

### [Abras Magic Maps](https://thunderstore.io/c/rounds/p/Abrachoo/Abras_Magic_Maps/)

- AMM_Catapult
- AMM_Dodgesaw
- AMM_FloatBox
- AMM_Maze
- AMM_Puppet
- AMM_thinBridge

### [CoolDromainMaps](https://thunderstore.io/c/rounds/p/Team_Dromian/CoolDromianMaps/)

- empty
- loveisintheair
- temple

### [mapsforbigmen](https://thunderstore.io/c/rounds/p/BigMen/mapsforbigmen/)

- Rattunnels

### [The Spectra Levels](https://thunderstore.io/c/rounds/p/TheSpectra/The_Spectra_Levels/)

#### *NOTE: these maps seem to be named differently in the editor for me. The names in parentheses are how they may appear in the TOGGLE LEVELS menu.*

- v4 map1 *( v4map1 )*
- v4 map5 sågar å sånt *( v5map5sågaråsånt )*
- v4 map7 zing zing *( v5map7zingzing )*
- v4 map8 såg trap *( v5map8sågtrap )*
- v4 map10 massa låda *( v5map1 )*

### [KingCookedBread_Map_Pack](https://thunderstore.io/c/rounds/p/Toasty/KingCookedBread_Map_Pack/)

- Crusher